#the first argument is the port number
javac client.java
g++ main.cpp
java client $1
