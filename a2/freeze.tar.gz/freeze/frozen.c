extern unsigned char M_BaseHTTPServer[];
extern unsigned char M_BmpImagePlugin[];
extern unsigned char M_ConfigParser[];
extern unsigned char M_FixTk[];
extern unsigned char M_GifImagePlugin[];
extern unsigned char M_GimpGradientFile[];
extern unsigned char M_GimpPaletteFile[];
extern unsigned char M_Image[];
extern unsigned char M_ImageChops[];
extern unsigned char M_ImageColor[];
extern unsigned char M_ImageFile[];
extern unsigned char M_ImageFilter[];
extern unsigned char M_ImageMode[];
extern unsigned char M_ImagePalette[];
extern unsigned char M_ImageShow[];
extern unsigned char M_JpegImagePlugin[];
extern unsigned char M_PIL[];
extern unsigned char M_PIL__BmpImagePlugin[];
extern unsigned char M_PIL__GifImagePlugin[];
extern unsigned char M_PIL__GimpGradientFile[];
extern unsigned char M_PIL__GimpPaletteFile[];
extern unsigned char M_PIL__Image[];
extern unsigned char M_PIL__ImageChops[];
extern unsigned char M_PIL__ImageColor[];
extern unsigned char M_PIL__ImageFile[];
extern unsigned char M_PIL__ImageFilter[];
extern unsigned char M_PIL__ImageMode[];
extern unsigned char M_PIL__ImagePalette[];
extern unsigned char M_PIL__ImageShow[];
extern unsigned char M_PIL__JpegImagePlugin[];
extern unsigned char M_PIL__PaletteFile[];
extern unsigned char M_PIL__PngImagePlugin[];
extern unsigned char M_PIL__PpmImagePlugin[];
extern unsigned char M_PIL__TiffImagePlugin[];
extern unsigned char M_PIL__TiffTags[];
extern unsigned char M_PaletteFile[];
extern unsigned char M_PngImagePlugin[];
extern unsigned char M_PpmImagePlugin[];
extern unsigned char M_PyQt4[];
extern unsigned char M_SocketServer[];
extern unsigned char M_StringIO[];
extern unsigned char M_TiffImagePlugin[];
extern unsigned char M_TiffTags[];
extern unsigned char M_Tkconstants[];
extern unsigned char M_Tkinter[];
extern unsigned char M_UserDict[];
extern unsigned char M__LWPCookieJar[];
extern unsigned char M__MozillaCookieJar[];
extern unsigned char M___future__[];
extern unsigned char M___main__[];
extern unsigned char M__abcoll[];
extern unsigned char M__sysconfigdata[];
extern unsigned char M__sysconfigdata_nd[];
extern unsigned char M__threading_local[];
extern unsigned char M__weakrefset[];
extern unsigned char M_abc[];
extern unsigned char M_apport[];
extern unsigned char M_apport__fileutils[];
extern unsigned char M_apport__packaging[];
extern unsigned char M_apport__packaging_impl[];
extern unsigned char M_apport__report[];
extern unsigned char M_apport_python_hook[];
extern unsigned char M_apt[];
extern unsigned char M_apt__cache[];
extern unsigned char M_apt__cdrom[];
extern unsigned char M_apt__deprecation[];
extern unsigned char M_apt__package[];
extern unsigned char M_apt__progress[];
extern unsigned char M_apt__progress__base[];
extern unsigned char M_apt__progress__old[];
extern unsigned char M_apt__progress__text[];
extern unsigned char M_ast[];
extern unsigned char M_atexit[];
extern unsigned char M_base64[];
extern unsigned char M_bdb[];
extern unsigned char M_bisect[];
extern unsigned char M_calendar[];
extern unsigned char M_cmd[];
extern unsigned char M_codecs[];
extern unsigned char M_collections[];
extern unsigned char M_colorsys[];
extern unsigned char M_commands[];
extern unsigned char M_compiler[];
extern unsigned char M_compiler__ast[];
extern unsigned char M_compiler__consts[];
extern unsigned char M_compiler__future[];
extern unsigned char M_compiler__misc[];
extern unsigned char M_compiler__pyassem[];
extern unsigned char M_compiler__pycodegen[];
extern unsigned char M_compiler__symbols[];
extern unsigned char M_compiler__syntax[];
extern unsigned char M_compiler__transformer[];
extern unsigned char M_compiler__visitor[];
extern unsigned char M_cookielib[];
extern unsigned char M_copy[];
extern unsigned char M_copy_reg[];
extern unsigned char M_csv[];
extern unsigned char M_ctypes[];
extern unsigned char M_ctypes___endian[];
extern unsigned char M_ctypes__util[];
extern unsigned char M_curses[];
extern unsigned char M_curses__has_key[];
extern unsigned char M_curses__wrapper[];
extern unsigned char M_dateutil[];
extern unsigned char M_dateutil__easter[];
extern unsigned char M_dateutil__parser[];
extern unsigned char M_dateutil__relativedelta[];
extern unsigned char M_dateutil__rrule[];
extern unsigned char M_dateutil__tz[];
extern unsigned char M_dateutil__tzwin[];
extern unsigned char M_dateutil__zoneinfo[];
extern unsigned char M_decimal[];
extern unsigned char M_difflib[];
extern unsigned char M_dis[];
extern unsigned char M_distutils[];
extern unsigned char M_distutils__archive_util[];
extern unsigned char M_distutils__ccompiler[];
extern unsigned char M_distutils__cmd[];
extern unsigned char M_distutils__command[];
extern unsigned char M_distutils__command__bdist_rpm[];
extern unsigned char M_distutils__command__build[];
extern unsigned char M_distutils__command__build_clib[];
extern unsigned char M_distutils__command__build_ext[];
extern unsigned char M_distutils__command__build_py[];
extern unsigned char M_distutils__command__build_scripts[];
extern unsigned char M_distutils__command__config[];
extern unsigned char M_distutils__command__install[];
extern unsigned char M_distutils__command__install_data[];
extern unsigned char M_distutils__command__install_headers[];
extern unsigned char M_distutils__command__sdist[];
extern unsigned char M_distutils__config[];
extern unsigned char M_distutils__core[];
extern unsigned char M_distutils__cygwinccompiler[];
extern unsigned char M_distutils__debug[];
extern unsigned char M_distutils__dep_util[];
extern unsigned char M_distutils__dir_util[];
extern unsigned char M_distutils__dist[];
extern unsigned char M_distutils__errors[];
extern unsigned char M_distutils__extension[];
extern unsigned char M_distutils__fancy_getopt[];
extern unsigned char M_distutils__file_util[];
extern unsigned char M_distutils__filelist[];
extern unsigned char M_distutils__log[];
extern unsigned char M_distutils__msvc9compiler[];
extern unsigned char M_distutils__msvccompiler[];
extern unsigned char M_distutils__spawn[];
extern unsigned char M_distutils__sysconfig[];
extern unsigned char M_distutils__text_file[];
extern unsigned char M_distutils__unixccompiler[];
extern unsigned char M_distutils__util[];
extern unsigned char M_distutils__version[];
extern unsigned char M_distutils__versionpredicate[];
extern unsigned char M_doctest[];
extern unsigned char M_dot_parser[];
extern unsigned char M_dummy_thread[];
extern unsigned char M_dummy_threading[];
extern unsigned char M_email[];
extern unsigned char M_email___parseaddr[];
extern unsigned char M_email__base64mime[];
extern unsigned char M_email__charset[];
extern unsigned char M_email__encoders[];
extern unsigned char M_email__errors[];
extern unsigned char M_email__feedparser[];
extern unsigned char M_email__generator[];
extern unsigned char M_email__header[];
extern unsigned char M_email__iterators[];
extern unsigned char M_email__message[];
extern unsigned char M_email__mime[];
extern unsigned char M_email__mime__base[];
extern unsigned char M_email__mime__multipart[];
extern unsigned char M_email__mime__nonmultipart[];
extern unsigned char M_email__mime__text[];
extern unsigned char M_email__parser[];
extern unsigned char M_email__quoprimime[];
extern unsigned char M_email__utils[];
extern unsigned char M_encodings[];
extern unsigned char M_encodings__aliases[];
extern unsigned char M_encodings__cp1252[];
extern unsigned char M_fileinput[];
extern unsigned char M_fnmatch[];
extern unsigned char M_formatter[];
extern unsigned char M_fractions[];
extern unsigned char M_ftplib[];
extern unsigned char M_functools[];
extern unsigned char M_genericpath[];
extern unsigned char M_getopt[];
extern unsigned char M_getpass[];
extern unsigned char M_gettext[];
extern unsigned char M_glib[];
extern unsigned char M_glib__option[];
extern unsigned char M_glob[];
extern unsigned char M_gobject[];
extern unsigned char M_gobject__constants[];
extern unsigned char M_gobject__propertyhelper[];
extern unsigned char M_gzip[];
extern unsigned char M_hashlib[];
extern unsigned char M_heapq[];
extern unsigned char M_httplib[];
extern unsigned char M_inspect[];
extern unsigned char M_io[];
extern unsigned char M_keyword[];
extern unsigned char M_linecache[];
extern unsigned char M_locale[];
extern unsigned char M_logging[];
extern unsigned char M_matplotlib[];
extern unsigned char M_matplotlib___cm[];
extern unsigned char M_matplotlib___mathtext_data[];
extern unsigned char M_matplotlib___pylab_helpers[];
extern unsigned char M_matplotlib__afm[];
extern unsigned char M_matplotlib__artist[];
extern unsigned char M_matplotlib__axes[];
extern unsigned char M_matplotlib__axis[];
extern unsigned char M_matplotlib__backend_bases[];
extern unsigned char M_matplotlib__backends[];
extern unsigned char M_matplotlib__backends__backend_agg[];
extern unsigned char M_matplotlib__backends__backend_emf[];
extern unsigned char M_matplotlib__backends__backend_mixed[];
extern unsigned char M_matplotlib__backends__backend_pdf[];
extern unsigned char M_matplotlib__backends__backend_ps[];
extern unsigned char M_matplotlib__backends__backend_svg[];
extern unsigned char M_matplotlib__bezier[];
extern unsigned char M_matplotlib__blocking_input[];
extern unsigned char M_matplotlib__cbook[];
extern unsigned char M_matplotlib__cm[];
extern unsigned char M_matplotlib__collections[];
extern unsigned char M_matplotlib__colorbar[];
extern unsigned char M_matplotlib__colors[];
extern unsigned char M_matplotlib__container[];
extern unsigned char M_matplotlib__contour[];
extern unsigned char M_matplotlib__dates[];
extern unsigned char M_matplotlib__delaunay[];
extern unsigned char M_matplotlib__delaunay__interpolate[];
extern unsigned char M_matplotlib__delaunay__triangulate[];
extern unsigned char M_matplotlib__docstring[];
extern unsigned char M_matplotlib__dviread[];
extern unsigned char M_matplotlib__figure[];
extern unsigned char M_matplotlib__finance[];
extern unsigned char M_matplotlib__font_manager[];
extern unsigned char M_matplotlib__fontconfig_pattern[];
extern unsigned char M_matplotlib__gridspec[];
extern unsigned char M_matplotlib__hatch[];
extern unsigned char M_matplotlib__image[];
extern unsigned char M_matplotlib__legend[];
extern unsigned char M_matplotlib__legend_handler[];
extern unsigned char M_matplotlib__lines[];
extern unsigned char M_matplotlib__markers[];
extern unsigned char M_matplotlib__mathtext[];
extern unsigned char M_matplotlib__mlab[];
extern unsigned char M_matplotlib__mpl[];
extern unsigned char M_matplotlib__offsetbox[];
extern unsigned char M_matplotlib__patches[];
extern unsigned char M_matplotlib__path[];
extern unsigned char M_matplotlib__projections[];
extern unsigned char M_matplotlib__projections__geo[];
extern unsigned char M_matplotlib__projections__polar[];
extern unsigned char M_matplotlib__pylab[];
extern unsigned char M_matplotlib__pyparsing[];
extern unsigned char M_matplotlib__pyplot[];
extern unsigned char M_matplotlib__quiver[];
extern unsigned char M_matplotlib__rcsetup[];
extern unsigned char M_matplotlib__scale[];
extern unsigned char M_matplotlib__spines[];
extern unsigned char M_matplotlib__table[];
extern unsigned char M_matplotlib__testing[];
extern unsigned char M_matplotlib__testing__noseclasses[];
extern unsigned char M_matplotlib__texmanager[];
extern unsigned char M_matplotlib__text[];
extern unsigned char M_matplotlib__textpath[];
extern unsigned char M_matplotlib__ticker[];
extern unsigned char M_matplotlib__tight_bbox[];
extern unsigned char M_matplotlib__tight_layout[];
extern unsigned char M_matplotlib__transforms[];
extern unsigned char M_matplotlib__tri[];
extern unsigned char M_matplotlib__tri__triangulation[];
extern unsigned char M_matplotlib__tri__tricontour[];
extern unsigned char M_matplotlib__tri__tripcolor[];
extern unsigned char M_matplotlib__tri__triplot[];
extern unsigned char M_matplotlib__type1font[];
extern unsigned char M_matplotlib__units[];
extern unsigned char M_matplotlib__widgets[];
extern unsigned char M_md5[];
extern unsigned char M_mimetools[];
extern unsigned char M_mimetypes[];
extern unsigned char M_mpl_toolkits[];
extern unsigned char M_networkx[];
extern unsigned char M_networkx__algorithms[];
extern unsigned char M_networkx__algorithms__assortativity[];
extern unsigned char M_networkx__algorithms__assortativity__connectivity[];
extern unsigned char M_networkx__algorithms__assortativity__correlation[];
extern unsigned char M_networkx__algorithms__assortativity__mixing[];
extern unsigned char M_networkx__algorithms__assortativity__neighbor_degree[];
extern unsigned char M_networkx__algorithms__assortativity__pairs[];
extern unsigned char M_networkx__algorithms__bipartite[];
extern unsigned char M_networkx__algorithms__bipartite__basic[];
extern unsigned char M_networkx__algorithms__bipartite__centrality[];
extern unsigned char M_networkx__algorithms__bipartite__cluster[];
extern unsigned char M_networkx__algorithms__bipartite__projection[];
extern unsigned char M_networkx__algorithms__bipartite__redundancy[];
extern unsigned char M_networkx__algorithms__bipartite__spectral[];
extern unsigned char M_networkx__algorithms__block[];
extern unsigned char M_networkx__algorithms__boundary[];
extern unsigned char M_networkx__algorithms__centrality[];
extern unsigned char M_networkx__algorithms__centrality__betweenness[];
extern unsigned char M_networkx__algorithms__centrality__betweenness_subset[];
extern unsigned char M_networkx__algorithms__centrality__closeness[];
extern unsigned char M_networkx__algorithms__centrality__communicability_alg[];
extern unsigned char M_networkx__algorithms__centrality__current_flow_betweenness[];
extern unsigned char M_networkx__algorithms__centrality__current_flow_betweenness_subset[];
extern unsigned char M_networkx__algorithms__centrality__current_flow_closeness[];
extern unsigned char M_networkx__algorithms__centrality__degree_alg[];
extern unsigned char M_networkx__algorithms__centrality__eigenvector[];
extern unsigned char M_networkx__algorithms__centrality__flow_matrix[];
extern unsigned char M_networkx__algorithms__centrality__load[];
extern unsigned char M_networkx__algorithms__chordal[];
extern unsigned char M_networkx__algorithms__chordal__chordal_alg[];
extern unsigned char M_networkx__algorithms__clique[];
extern unsigned char M_networkx__algorithms__cluster[];
extern unsigned char M_networkx__algorithms__community[];
extern unsigned char M_networkx__algorithms__community__kclique[];
extern unsigned char M_networkx__algorithms__components[];
extern unsigned char M_networkx__algorithms__components__attracting[];
extern unsigned char M_networkx__algorithms__components__biconnected[];
extern unsigned char M_networkx__algorithms__components__connected[];
extern unsigned char M_networkx__algorithms__components__strongly_connected[];
extern unsigned char M_networkx__algorithms__components__weakly_connected[];
extern unsigned char M_networkx__algorithms__core[];
extern unsigned char M_networkx__algorithms__cycles[];
extern unsigned char M_networkx__algorithms__dag[];
extern unsigned char M_networkx__algorithms__distance_measures[];
extern unsigned char M_networkx__algorithms__distance_regular[];
extern unsigned char M_networkx__algorithms__euler[];
extern unsigned char M_networkx__algorithms__flow[];
extern unsigned char M_networkx__algorithms__flow__maxflow[];
extern unsigned char M_networkx__algorithms__flow__mincost[];
extern unsigned char M_networkx__algorithms__graphical[];
extern unsigned char M_networkx__algorithms__hierarchy[];
extern unsigned char M_networkx__algorithms__isolate[];
extern unsigned char M_networkx__algorithms__isomorphism[];
extern unsigned char M_networkx__algorithms__isomorphism__isomorph[];
extern unsigned char M_networkx__algorithms__isomorphism__isomorphvf2[];
extern unsigned char M_networkx__algorithms__isomorphism__matchhelpers[];
extern unsigned char M_networkx__algorithms__isomorphism__vf2userfunc[];
extern unsigned char M_networkx__algorithms__link_analysis[];
extern unsigned char M_networkx__algorithms__link_analysis__hits_alg[];
extern unsigned char M_networkx__algorithms__link_analysis__pagerank_alg[];
extern unsigned char M_networkx__algorithms__matching[];
extern unsigned char M_networkx__algorithms__mis[];
extern unsigned char M_networkx__algorithms__mst[];
extern unsigned char M_networkx__algorithms__operators[];
extern unsigned char M_networkx__algorithms__operators__all[];
extern unsigned char M_networkx__algorithms__operators__binary[];
extern unsigned char M_networkx__algorithms__operators__product[];
extern unsigned char M_networkx__algorithms__operators__unary[];
extern unsigned char M_networkx__algorithms__richclub[];
extern unsigned char M_networkx__algorithms__shortest_paths[];
extern unsigned char M_networkx__algorithms__shortest_paths__astar[];
extern unsigned char M_networkx__algorithms__shortest_paths__dense[];
extern unsigned char M_networkx__algorithms__shortest_paths__generic[];
extern unsigned char M_networkx__algorithms__shortest_paths__unweighted[];
extern unsigned char M_networkx__algorithms__shortest_paths__weighted[];
extern unsigned char M_networkx__algorithms__simple_paths[];
extern unsigned char M_networkx__algorithms__smetric[];
extern unsigned char M_networkx__algorithms__swap[];
extern unsigned char M_networkx__algorithms__traversal[];
extern unsigned char M_networkx__algorithms__traversal__breadth_first_search[];
extern unsigned char M_networkx__algorithms__traversal__depth_first_search[];
extern unsigned char M_networkx__algorithms__vitality[];
extern unsigned char M_networkx__classes[];
extern unsigned char M_networkx__classes__digraph[];
extern unsigned char M_networkx__classes__function[];
extern unsigned char M_networkx__classes__graph[];
extern unsigned char M_networkx__classes__multidigraph[];
extern unsigned char M_networkx__classes__multigraph[];
extern unsigned char M_networkx__convert[];
extern unsigned char M_networkx__drawing[];
extern unsigned char M_networkx__drawing__layout[];
extern unsigned char M_networkx__drawing__nx_agraph[];
extern unsigned char M_networkx__drawing__nx_pydot[];
extern unsigned char M_networkx__drawing__nx_pylab[];
extern unsigned char M_networkx__exception[];
extern unsigned char M_networkx__external[];
extern unsigned char M_networkx__external__decorator[];
extern unsigned char M_networkx__external__decorator___decorator[];
extern unsigned char M_networkx__external__decorator___decorator3[];
extern unsigned char M_networkx__generators[];
extern unsigned char M_networkx__generators__atlas[];
extern unsigned char M_networkx__generators__bipartite[];
extern unsigned char M_networkx__generators__classic[];
extern unsigned char M_networkx__generators__degree_seq[];
extern unsigned char M_networkx__generators__directed[];
extern unsigned char M_networkx__generators__ego[];
extern unsigned char M_networkx__generators__geometric[];
extern unsigned char M_networkx__generators__hybrid[];
extern unsigned char M_networkx__generators__intersection[];
extern unsigned char M_networkx__generators__line[];
extern unsigned char M_networkx__generators__random_clustered[];
extern unsigned char M_networkx__generators__random_graphs[];
extern unsigned char M_networkx__generators__small[];
extern unsigned char M_networkx__generators__social[];
extern unsigned char M_networkx__generators__stochastic[];
extern unsigned char M_networkx__generators__threshold[];
extern unsigned char M_networkx__linalg[];
extern unsigned char M_networkx__linalg__attrmatrix[];
extern unsigned char M_networkx__linalg__graphmatrix[];
extern unsigned char M_networkx__linalg__laplacianmatrix[];
extern unsigned char M_networkx__linalg__spectrum[];
extern unsigned char M_networkx__readwrite[];
extern unsigned char M_networkx__readwrite__adjlist[];
extern unsigned char M_networkx__readwrite__edgelist[];
extern unsigned char M_networkx__readwrite__gexf[];
extern unsigned char M_networkx__readwrite__gml[];
extern unsigned char M_networkx__readwrite__gpickle[];
extern unsigned char M_networkx__readwrite__graphml[];
extern unsigned char M_networkx__readwrite__leda[];
extern unsigned char M_networkx__readwrite__multiline_adjlist[];
extern unsigned char M_networkx__readwrite__nx_shp[];
extern unsigned char M_networkx__readwrite__nx_yaml[];
extern unsigned char M_networkx__readwrite__pajek[];
extern unsigned char M_networkx__readwrite__sparsegraph6[];
extern unsigned char M_networkx__relabel[];
extern unsigned char M_networkx__release[];
extern unsigned char M_networkx__tests[];
extern unsigned char M_networkx__tests__test[];
extern unsigned char M_networkx__utils[];
extern unsigned char M_networkx__utils__decorators[];
extern unsigned char M_networkx__utils__misc[];
extern unsigned char M_networkx__utils__random_sequence[];
extern unsigned char M_networkx__utils__rcm[];
extern unsigned char M_networkx__utils__union_find[];
extern unsigned char M_new[];
extern unsigned char M_ntpath[];
extern unsigned char M_nturl2path[];
extern unsigned char M_numbers[];
extern unsigned char M_numpy[];
extern unsigned char M_numpy____config__[];
extern unsigned char M_numpy___import_tools[];
extern unsigned char M_numpy__add_newdocs[];
extern unsigned char M_numpy__compat[];
extern unsigned char M_numpy__compat___inspect[];
extern unsigned char M_numpy__compat__py3k[];
extern unsigned char M_numpy__core[];
extern unsigned char M_numpy__core___internal[];
extern unsigned char M_numpy__core__arrayprint[];
extern unsigned char M_numpy__core__defchararray[];
extern unsigned char M_numpy__core__fromnumeric[];
extern unsigned char M_numpy__core__function_base[];
extern unsigned char M_numpy__core__getlimits[];
extern unsigned char M_numpy__core__info[];
extern unsigned char M_numpy__core__machar[];
extern unsigned char M_numpy__core__memmap[];
extern unsigned char M_numpy__core__numeric[];
extern unsigned char M_numpy__core__numerictypes[];
extern unsigned char M_numpy__core__records[];
extern unsigned char M_numpy__core__shape_base[];
extern unsigned char M_numpy__ctypeslib[];
extern unsigned char M_numpy__distutils[];
extern unsigned char M_numpy__distutils____config__[];
extern unsigned char M_numpy__distutils____version__[];
extern unsigned char M_numpy__distutils__ccompiler[];
extern unsigned char M_numpy__distutils__command[];
extern unsigned char M_numpy__distutils__command__autodist[];
extern unsigned char M_numpy__distutils__command__bdist_rpm[];
extern unsigned char M_numpy__distutils__command__build[];
extern unsigned char M_numpy__distutils__command__build_clib[];
extern unsigned char M_numpy__distutils__command__build_ext[];
extern unsigned char M_numpy__distutils__command__build_py[];
extern unsigned char M_numpy__distutils__command__build_scripts[];
extern unsigned char M_numpy__distutils__command__build_src[];
extern unsigned char M_numpy__distutils__command__config[];
extern unsigned char M_numpy__distutils__command__config_compiler[];
extern unsigned char M_numpy__distutils__command__develop[];
extern unsigned char M_numpy__distutils__command__egg_info[];
extern unsigned char M_numpy__distutils__command__install[];
extern unsigned char M_numpy__distutils__command__install_clib[];
extern unsigned char M_numpy__distutils__command__install_data[];
extern unsigned char M_numpy__distutils__command__install_headers[];
extern unsigned char M_numpy__distutils__command__scons[];
extern unsigned char M_numpy__distutils__command__sdist[];
extern unsigned char M_numpy__distutils__compat[];
extern unsigned char M_numpy__distutils__conv_template[];
extern unsigned char M_numpy__distutils__core[];
extern unsigned char M_numpy__distutils__cpuinfo[];
extern unsigned char M_numpy__distutils__environment[];
extern unsigned char M_numpy__distutils__exec_command[];
extern unsigned char M_numpy__distutils__extension[];
extern unsigned char M_numpy__distutils__fcompiler[];
extern unsigned char M_numpy__distutils__from_template[];
extern unsigned char M_numpy__distutils__info[];
extern unsigned char M_numpy__distutils__interactive[];
extern unsigned char M_numpy__distutils__lib2def[];
extern unsigned char M_numpy__distutils__log[];
extern unsigned char M_numpy__distutils__mingw32ccompiler[];
extern unsigned char M_numpy__distutils__misc_util[];
extern unsigned char M_numpy__distutils__npy_pkg_config[];
extern unsigned char M_numpy__distutils__numpy_distribution[];
extern unsigned char M_numpy__distutils__system_info[];
extern unsigned char M_numpy__distutils__unixccompiler[];
extern unsigned char M_numpy__dual[];
extern unsigned char M_numpy__f2py[];
extern unsigned char M_numpy__f2py____version__[];
extern unsigned char M_numpy__f2py__auxfuncs[];
extern unsigned char M_numpy__f2py__capi_maps[];
extern unsigned char M_numpy__f2py__cb_rules[];
extern unsigned char M_numpy__f2py__cfuncs[];
extern unsigned char M_numpy__f2py__common_rules[];
extern unsigned char M_numpy__f2py__crackfortran[];
extern unsigned char M_numpy__f2py__diagnose[];
extern unsigned char M_numpy__f2py__f2py2e[];
extern unsigned char M_numpy__f2py__f2py_testing[];
extern unsigned char M_numpy__f2py__f90mod_rules[];
extern unsigned char M_numpy__f2py__func2subr[];
extern unsigned char M_numpy__f2py__info[];
extern unsigned char M_numpy__f2py__rules[];
extern unsigned char M_numpy__f2py__use_rules[];
extern unsigned char M_numpy__fft[];
extern unsigned char M_numpy__fft__fftpack[];
extern unsigned char M_numpy__fft__helper[];
extern unsigned char M_numpy__fft__info[];
extern unsigned char M_numpy__lib[];
extern unsigned char M_numpy__lib___datasource[];
extern unsigned char M_numpy__lib___iotools[];
extern unsigned char M_numpy__lib__arraysetops[];
extern unsigned char M_numpy__lib__arrayterator[];
extern unsigned char M_numpy__lib__financial[];
extern unsigned char M_numpy__lib__format[];
extern unsigned char M_numpy__lib__function_base[];
extern unsigned char M_numpy__lib__index_tricks[];
extern unsigned char M_numpy__lib__info[];
extern unsigned char M_numpy__lib__npyio[];
extern unsigned char M_numpy__lib__polynomial[];
extern unsigned char M_numpy__lib__scimath[];
extern unsigned char M_numpy__lib__shape_base[];
extern unsigned char M_numpy__lib__stride_tricks[];
extern unsigned char M_numpy__lib__twodim_base[];
extern unsigned char M_numpy__lib__type_check[];
extern unsigned char M_numpy__lib__ufunclike[];
extern unsigned char M_numpy__lib__utils[];
extern unsigned char M_numpy__linalg[];
extern unsigned char M_numpy__linalg__info[];
extern unsigned char M_numpy__linalg__linalg[];
extern unsigned char M_numpy__ma[];
extern unsigned char M_numpy__ma__core[];
extern unsigned char M_numpy__ma__extras[];
extern unsigned char M_numpy__ma__mrecords[];
extern unsigned char M_numpy__matrixlib[];
extern unsigned char M_numpy__matrixlib__defmatrix[];
extern unsigned char M_numpy__numarray[];
extern unsigned char M_numpy__numarray__compat[];
extern unsigned char M_numpy__numarray__functions[];
extern unsigned char M_numpy__numarray__numerictypes[];
extern unsigned char M_numpy__numarray__session[];
extern unsigned char M_numpy__numarray__ufuncs[];
extern unsigned char M_numpy__numarray__util[];
extern unsigned char M_numpy__oldnumeric[];
extern unsigned char M_numpy__oldnumeric__array_printer[];
extern unsigned char M_numpy__oldnumeric__compat[];
extern unsigned char M_numpy__oldnumeric__functions[];
extern unsigned char M_numpy__oldnumeric__misc[];
extern unsigned char M_numpy__oldnumeric__precision[];
extern unsigned char M_numpy__oldnumeric__typeconv[];
extern unsigned char M_numpy__oldnumeric__ufuncs[];
extern unsigned char M_numpy__polynomial[];
extern unsigned char M_numpy__polynomial__chebyshev[];
extern unsigned char M_numpy__polynomial__hermite[];
extern unsigned char M_numpy__polynomial__hermite_e[];
extern unsigned char M_numpy__polynomial__laguerre[];
extern unsigned char M_numpy__polynomial__legendre[];
extern unsigned char M_numpy__polynomial__polynomial[];
extern unsigned char M_numpy__polynomial__polytemplate[];
extern unsigned char M_numpy__polynomial__polyutils[];
extern unsigned char M_numpy__random[];
extern unsigned char M_numpy__random__info[];
extern unsigned char M_numpy__testing[];
extern unsigned char M_numpy__testing__decorators[];
extern unsigned char M_numpy__testing__noseclasses[];
extern unsigned char M_numpy__testing__nosetester[];
extern unsigned char M_numpy__testing__numpytest[];
extern unsigned char M_numpy__testing__utils[];
extern unsigned char M_numpy__version[];
extern unsigned char M_opcode[];
extern unsigned char M_optparse[];
extern unsigned char M_os[];
extern unsigned char M_os2emxpath[];
extern unsigned char M_pdb[];
extern unsigned char M_pickle[];
extern unsigned char M_pkgutil[];
extern unsigned char M_platform[];
extern unsigned char M_plistlib[];
extern unsigned char M_posixpath[];
extern unsigned char M_pprint[];
extern unsigned char M_problem_report[];
extern unsigned char M_py_compile[];
extern unsigned char M_pydoc[];
extern unsigned char M_pydoc_data[];
extern unsigned char M_pydoc_data__topics[];
extern unsigned char M_pydot[];
extern unsigned char M_pylab[];
extern unsigned char M_pyparsing[];
extern unsigned char M_pytz[];
extern unsigned char M_pytz__exceptions[];
extern unsigned char M_pytz__tzfile[];
extern unsigned char M_pytz__tzinfo[];
extern unsigned char M_quopri[];
extern unsigned char M_random[];
extern unsigned char M_re[];
extern unsigned char M_repr[];
extern unsigned char M_rfc822[];
extern unsigned char M_scipy[];
extern unsigned char M_scipy____config__[];
extern unsigned char M_scipy__integrate[];
extern unsigned char M_scipy__integrate___ode[];
extern unsigned char M_scipy__integrate__odepack[];
extern unsigned char M_scipy__integrate__quadpack[];
extern unsigned char M_scipy__integrate__quadrature[];
extern unsigned char M_scipy__lib[];
extern unsigned char M_scipy__lib__lapack[];
extern unsigned char M_scipy__lib__lapack__info[];
extern unsigned char M_scipy__linalg[];
extern unsigned char M_scipy__linalg__basic[];
extern unsigned char M_scipy__linalg__blas[];
extern unsigned char M_scipy__linalg__decomp[];
extern unsigned char M_scipy__linalg__decomp_cholesky[];
extern unsigned char M_scipy__linalg__decomp_lu[];
extern unsigned char M_scipy__linalg__decomp_qr[];
extern unsigned char M_scipy__linalg__decomp_schur[];
extern unsigned char M_scipy__linalg__decomp_svd[];
extern unsigned char M_scipy__linalg__flinalg[];
extern unsigned char M_scipy__linalg__lapack[];
extern unsigned char M_scipy__linalg__linalg_version[];
extern unsigned char M_scipy__linalg__matfuncs[];
extern unsigned char M_scipy__linalg__misc[];
extern unsigned char M_scipy__linalg__special_matrices[];
extern unsigned char M_scipy__misc[];
extern unsigned char M_scipy__misc__common[];
extern unsigned char M_scipy__misc__doccer[];
extern unsigned char M_scipy__misc__pilutil[];
extern unsigned char M_scipy__optimize[];
extern unsigned char M_scipy__optimize__anneal[];
extern unsigned char M_scipy__optimize__cobyla[];
extern unsigned char M_scipy__optimize__lbfgsb[];
extern unsigned char M_scipy__optimize__linesearch[];
extern unsigned char M_scipy__optimize__minpack[];
extern unsigned char M_scipy__optimize__nnls[];
extern unsigned char M_scipy__optimize__nonlin[];
extern unsigned char M_scipy__optimize__optimize[];
extern unsigned char M_scipy__optimize__slsqp[];
extern unsigned char M_scipy__optimize__tnc[];
extern unsigned char M_scipy__optimize__zeros[];
extern unsigned char M_scipy__sparse[];
extern unsigned char M_scipy__sparse__base[];
extern unsigned char M_scipy__sparse__bsr[];
extern unsigned char M_scipy__sparse__compressed[];
extern unsigned char M_scipy__sparse__construct[];
extern unsigned char M_scipy__sparse__coo[];
extern unsigned char M_scipy__sparse__csc[];
extern unsigned char M_scipy__sparse__csgraph[];
extern unsigned char M_scipy__sparse__csr[];
extern unsigned char M_scipy__sparse__data[];
extern unsigned char M_scipy__sparse__dia[];
extern unsigned char M_scipy__sparse__dok[];
extern unsigned char M_scipy__sparse__extract[];
extern unsigned char M_scipy__sparse__lil[];
extern unsigned char M_scipy__sparse__linalg[];
extern unsigned char M_scipy__sparse__linalg__dsolve[];
extern unsigned char M_scipy__sparse__linalg__dsolve__info[];
extern unsigned char M_scipy__sparse__linalg__dsolve__linsolve[];
extern unsigned char M_scipy__sparse__linalg__dsolve__umfpack[];
extern unsigned char M_scipy__sparse__linalg__dsolve__umfpack___umfpack[];
extern unsigned char M_scipy__sparse__linalg__dsolve__umfpack__info[];
extern unsigned char M_scipy__sparse__linalg__dsolve__umfpack__umfpack[];
extern unsigned char M_scipy__sparse__linalg__eigen[];
extern unsigned char M_scipy__sparse__linalg__eigen__arpack[];
extern unsigned char M_scipy__sparse__linalg__eigen__arpack__arpack[];
extern unsigned char M_scipy__sparse__linalg__eigen__arpack__info[];
extern unsigned char M_scipy__sparse__linalg__eigen__info[];
extern unsigned char M_scipy__sparse__linalg__eigen__lobpcg[];
extern unsigned char M_scipy__sparse__linalg__eigen__lobpcg__info[];
extern unsigned char M_scipy__sparse__linalg__eigen__lobpcg__lobpcg[];
extern unsigned char M_scipy__sparse__linalg__info[];
extern unsigned char M_scipy__sparse__linalg__interface[];
extern unsigned char M_scipy__sparse__linalg__isolve[];
extern unsigned char M_scipy__sparse__linalg__isolve__iterative[];
extern unsigned char M_scipy__sparse__linalg__isolve__lgmres[];
extern unsigned char M_scipy__sparse__linalg__isolve__lsqr[];
extern unsigned char M_scipy__sparse__linalg__isolve__minres[];
extern unsigned char M_scipy__sparse__linalg__isolve__utils[];
extern unsigned char M_scipy__sparse__sparsetools[];
extern unsigned char M_scipy__sparse__sparsetools__bsr[];
extern unsigned char M_scipy__sparse__sparsetools__coo[];
extern unsigned char M_scipy__sparse__sparsetools__csc[];
extern unsigned char M_scipy__sparse__sparsetools__csgraph[];
extern unsigned char M_scipy__sparse__sparsetools__csr[];
extern unsigned char M_scipy__sparse__sparsetools__dia[];
extern unsigned char M_scipy__sparse__spfuncs[];
extern unsigned char M_scipy__sparse__sputils[];
extern unsigned char M_scipy__spatial[];
extern unsigned char M_scipy__spatial__distance[];
extern unsigned char M_scipy__spatial__kdtree[];
extern unsigned char M_scipy__special[];
extern unsigned char M_scipy__special__add_newdocs[];
extern unsigned char M_scipy__special__basic[];
extern unsigned char M_scipy__special__orthogonal[];
extern unsigned char M_scipy__special__spfun_stats[];
extern unsigned char M_scipy__stats[];
extern unsigned char M_scipy__stats___support[];
extern unsigned char M_scipy__stats__contingency[];
extern unsigned char M_scipy__stats__distributions[];
extern unsigned char M_scipy__stats__kde[];
extern unsigned char M_scipy__stats__morestats[];
extern unsigned char M_scipy__stats__mstats[];
extern unsigned char M_scipy__stats__mstats_basic[];
extern unsigned char M_scipy__stats__mstats_extras[];
extern unsigned char M_scipy__stats__rv[];
extern unsigned char M_scipy__stats__stats[];
extern unsigned char M_scipy__version[];
extern unsigned char M_sets[];
extern unsigned char M_shlex[];
extern unsigned char M_shutil[];
extern unsigned char M_site[];
extern unsigned char M_sitecustomize[];
extern unsigned char M_socket[];
extern unsigned char M_sre_compile[];
extern unsigned char M_sre_constants[];
extern unsigned char M_sre_parse[];
extern unsigned char M_ssl[];
extern unsigned char M_stat[];
extern unsigned char M_string[];
extern unsigned char M_struct[];
extern unsigned char M_subprocess[];
extern unsigned char M_symbol[];
extern unsigned char M_symtable[];
extern unsigned char M_sysconfig[];
extern unsigned char M_tarfile[];
extern unsigned char M_tempfile[];
extern unsigned char M_textwrap[];
extern unsigned char M_threading[];
extern unsigned char M_token[];
extern unsigned char M_tokenize[];
extern unsigned char M_traceback[];
extern unsigned char M_tty[];
extern unsigned char M_types[];
extern unsigned char M_unittest[];
extern unsigned char M_unittest__case[];
extern unsigned char M_unittest__loader[];
extern unsigned char M_unittest__main[];
extern unsigned char M_unittest__result[];
extern unsigned char M_unittest__runner[];
extern unsigned char M_unittest__signals[];
extern unsigned char M_unittest__suite[];
extern unsigned char M_unittest__util[];
extern unsigned char M_urllib[];
extern unsigned char M_urllib2[];
extern unsigned char M_urlparse[];
extern unsigned char M_uu[];
extern unsigned char M_uuid[];
extern unsigned char M_warnings[];
extern unsigned char M_weakref[];
extern unsigned char M_webbrowser[];
extern unsigned char M_xml[];
extern unsigned char M_xml__dom[];
extern unsigned char M_xml__dom__NodeFilter[];
extern unsigned char M_xml__dom__domreg[];
extern unsigned char M_xml__dom__expatbuilder[];
extern unsigned char M_xml__dom__minicompat[];
extern unsigned char M_xml__dom__minidom[];
extern unsigned char M_xml__dom__pulldom[];
extern unsigned char M_xml__dom__xmlbuilder[];
extern unsigned char M_xml__etree[];
extern unsigned char M_xml__etree__ElementPath[];
extern unsigned char M_xml__etree__ElementTree[];
extern unsigned char M_xml__etree__cElementTree[];
extern unsigned char M_xml__parsers[];
extern unsigned char M_xml__parsers__expat[];
extern unsigned char M_xml__sax[];
extern unsigned char M_xml__sax___exceptions[];
extern unsigned char M_xml__sax__expatreader[];
extern unsigned char M_xml__sax__handler[];
extern unsigned char M_xml__sax__saxutils[];
extern unsigned char M_xml__sax__xmlreader[];
extern unsigned char M_yaml[];
extern unsigned char M_yaml__composer[];
extern unsigned char M_yaml__constructor[];
extern unsigned char M_yaml__cyaml[];
extern unsigned char M_yaml__dumper[];
extern unsigned char M_yaml__emitter[];
extern unsigned char M_yaml__error[];
extern unsigned char M_yaml__events[];
extern unsigned char M_yaml__loader[];
extern unsigned char M_yaml__nodes[];
extern unsigned char M_yaml__parser[];
extern unsigned char M_yaml__reader[];
extern unsigned char M_yaml__representer[];
extern unsigned char M_yaml__resolver[];
extern unsigned char M_yaml__scanner[];
extern unsigned char M_yaml__serializer[];
extern unsigned char M_yaml__tokens[];
extern unsigned char M_zipfile[];

#include "Python.h"

static struct _frozen _PyImport_FrozenModules[] = {
	{"BaseHTTPServer", M_BaseHTTPServer, 21704},
	{"BmpImagePlugin", M_BmpImagePlugin, 6161},
	{"ConfigParser", M_ConfigParser, 25087},
	{"FixTk", M_FixTk, 1987},
	{"GifImagePlugin", M_GifImagePlugin, 8172},
	{"GimpGradientFile", M_GimpGradientFile, 3643},
	{"GimpPaletteFile", M_GimpPaletteFile, 1612},
	{"Image", M_Image, 37837},
	{"ImageChops", M_ImageChops, 5024},
	{"ImageColor", M_ImageColor, 7218},
	{"ImageFile", M_ImageFile, 11165},
	{"ImageFilter", M_ImageFilter, 8793},
	{"ImageMode", M_ImageMode, 1330},
	{"ImagePalette", M_ImagePalette, 5601},
	{"ImageShow", M_ImageShow, 5162},
	{"JpegImagePlugin", M_JpegImagePlugin, 13873},
	{"PIL", M_PIL, -127},
	{"PIL.BmpImagePlugin", M_PIL__BmpImagePlugin, 6161},
	{"PIL.GifImagePlugin", M_PIL__GifImagePlugin, 8160},
	{"PIL.GimpGradientFile", M_PIL__GimpGradientFile, 3643},
	{"PIL.GimpPaletteFile", M_PIL__GimpPaletteFile, 1612},
	{"PIL.Image", M_PIL__Image, 37829},
	{"PIL.ImageChops", M_PIL__ImageChops, 5024},
	{"PIL.ImageColor", M_PIL__ImageColor, 7218},
	{"PIL.ImageFile", M_PIL__ImageFile, 11165},
	{"PIL.ImageFilter", M_PIL__ImageFilter, 8793},
	{"PIL.ImageMode", M_PIL__ImageMode, 1330},
	{"PIL.ImagePalette", M_PIL__ImagePalette, 5601},
	{"PIL.ImageShow", M_PIL__ImageShow, 5162},
	{"PIL.JpegImagePlugin", M_PIL__JpegImagePlugin, 13772},
	{"PIL.PaletteFile", M_PIL__PaletteFile, 1404},
	{"PIL.PngImagePlugin", M_PIL__PngImagePlugin, 18066},
	{"PIL.PpmImagePlugin", M_PIL__PpmImagePlugin, 2874},
	{"PIL.TiffImagePlugin", M_PIL__TiffImagePlugin, 23994},
	{"PIL.TiffTags", M_PIL__TiffTags, 5005},
	{"PaletteFile", M_PaletteFile, 1404},
	{"PngImagePlugin", M_PngImagePlugin, 18074},
	{"PpmImagePlugin", M_PpmImagePlugin, 2882},
	{"PyQt4", M_PyQt4, -129},
	{"SocketServer", M_SocketServer, 23887},
	{"StringIO", M_StringIO, 11434},
	{"TiffImagePlugin", M_TiffImagePlugin, 23994},
	{"TiffTags", M_TiffTags, 5005},
	{"Tkconstants", M_Tkconstants, 2236},
	{"Tkinter", M_Tkinter, 195583},
	{"UserDict", M_UserDict, 8722},
	{"_LWPCookieJar", M__LWPCookieJar, 5512},
	{"_MozillaCookieJar", M__MozillaCookieJar, 4456},
	{"__future__", M___future__, 4272},
	{"__main__", M___main__, 1726},
	{"_abcoll", M__abcoll, 21717},
	{"_sysconfigdata", M__sysconfigdata, 271},
	{"_sysconfigdata_nd", M__sysconfigdata_nd, 18764},
	{"_threading_local", M__threading_local, 6578},
	{"_weakrefset", M__weakrefset, 9375},
	{"abc", M_abc, 6113},
	{"apport", M_apport, -2168},
	{"apport.fileutils", M_apport__fileutils, 10131},
	{"apport.packaging", M_apport__packaging, 11297},
	{"apport.packaging_impl", M_apport__packaging_impl, 29545},
	{"apport.report", M_apport__report, 41587},
	{"apport_python_hook", M_apport_python_hook, 5088},
	{"apt", M_apt, -811},
	{"apt.cache", M_apt__cache, 27831},
	{"apt.cdrom", M_apt__cdrom, 2829},
	{"apt.deprecation", M_apt__deprecation, 4016},
	{"apt.package", M_apt__package, 53202},
	{"apt.progress", M_apt__progress, -784},
	{"apt.progress.base", M_apt__progress__base, 12446},
	{"apt.progress.old", M_apt__progress__old, 11609},
	{"apt.progress.text", M_apt__progress__text, 9739},
	{"ast", M_ast, 12898},
	{"atexit", M_atexit, 2183},
	{"base64", M_base64, 10844},
	{"bdb", M_bdb, 18971},
	{"bisect", M_bisect, 3053},
	{"calendar", M_calendar, 27550},
	{"cmd", M_cmd, 13989},
	{"codecs", M_codecs, 36406},
	{"collections", M_collections, 24579},
	{"colorsys", M_colorsys, 3967},
	{"commands", M_commands, 2449},
	{"compiler", M_compiler, -1287},
	{"compiler.ast", M_compiler__ast, 71339},
	{"compiler.consts", M_compiler__consts, 727},
	{"compiler.future", M_compiler__future, 3018},
	{"compiler.misc", M_compiler__misc, 3687},
	{"compiler.pyassem", M_compiler__pyassem, 25829},
	{"compiler.pycodegen", M_compiler__pycodegen, 56161},
	{"compiler.symbols", M_compiler__symbols, 17557},
	{"compiler.syntax", M_compiler__syntax, 1862},
	{"compiler.transformer", M_compiler__transformer, 47371},
	{"compiler.visitor", M_compiler__visitor, 4159},
	{"cookielib", M_cookielib, 54516},
	{"copy", M_copy, 12134},
	{"copy_reg", M_copy_reg, 5083},
	{"csv", M_csv, 13392},
	{"ctypes", M_ctypes, -20192},
	{"ctypes._endian", M_ctypes___endian, 2287},
	{"ctypes.util", M_ctypes__util, 7166},
	{"curses", M_curses, -1544},
	{"curses.has_key", M_curses__has_key, 5925},
	{"curses.wrapper", M_curses__wrapper, 1206},
	{"dateutil", M_dateutil, -436},
	{"dateutil.easter", M_dateutil__easter, 2431},
	{"dateutil.parser", M_dateutil__parser, 22091},
	{"dateutil.relativedelta", M_dateutil__relativedelta, 14271},
	{"dateutil.rrule", M_dateutil__rrule, 28488},
	{"dateutil.tz", M_dateutil__tz, 24499},
	{"dateutil.tzwin", M_dateutil__tzwin, 6746},
	{"dateutil.zoneinfo", M_dateutil__zoneinfo, -3352},
	{"decimal", M_decimal, 170824},
	{"difflib", M_difflib, 61833},
	{"dis", M_dis, 6204},
	{"distutils", M_distutils, -375},
	{"distutils.archive_util", M_distutils__archive_util, 7432},
	{"distutils.ccompiler", M_distutils__ccompiler, 36631},
	{"distutils.cmd", M_distutils__cmd, 16722},
	{"distutils.command", M_distutils__command, -655},
	{"distutils.command.bdist_rpm", M_distutils__command__bdist_rpm, 17710},
	{"distutils.command.build", M_distutils__command__build, 5125},
	{"distutils.command.build_clib", M_distutils__command__build_clib, 6405},
	{"distutils.command.build_ext", M_distutils__command__build_ext, 19430},
	{"distutils.command.build_py", M_distutils__command__build_py, 11458},
	{"distutils.command.build_scripts", M_distutils__command__build_scripts, 4512},
	{"distutils.command.config", M_distutils__command__config, 12641},
	{"distutils.command.install", M_distutils__command__install, 17981},
	{"distutils.command.install_data", M_distutils__command__install_data, 3142},
	{"distutils.command.install_headers", M_distutils__command__install_headers, 2274},
	{"distutils.command.sdist", M_distutils__command__sdist, 16656},
	{"distutils.config", M_distutils__config, 3617},
	{"distutils.core", M_distutils__core, 7839},
	{"distutils.cygwinccompiler", M_distutils__cygwinccompiler, 9378},
	{"distutils.debug", M_distutils__debug, 244},
	{"distutils.dep_util", M_distutils__dep_util, 3164},
	{"distutils.dir_util", M_distutils__dir_util, 6857},
	{"distutils.dist", M_distutils__dist, 39429},
	{"distutils.errors", M_distutils__errors, 6237},
	{"distutils.extension", M_distutils__extension, 7395},
	{"distutils.fancy_getopt", M_distutils__fancy_getopt, 11908},
	{"distutils.file_util", M_distutils__file_util, 6608},
	{"distutils.filelist", M_distutils__filelist, 10733},
	{"distutils.log", M_distutils__log, 2754},
	{"distutils.msvc9compiler", M_distutils__msvc9compiler, 21470},
	{"distutils.msvccompiler", M_distutils__msvccompiler, 17463},
	{"distutils.spawn", M_distutils__spawn, 6145},
	{"distutils.sysconfig", M_distutils__sysconfig, 16640},
	{"distutils.text_file", M_distutils__text_file, 9214},
	{"distutils.unixccompiler", M_distutils__unixccompiler, 9139},
	{"distutils.util", M_distutils__util, 16183},
	{"distutils.version", M_distutils__version, 7170},
	{"distutils.versionpredicate", M_distutils__versionpredicate, 5520},
	{"doctest", M_doctest, 83157},
	{"dot_parser", M_dot_parser, 12227},
	{"dummy_thread", M_dummy_thread, 5356},
	{"dummy_threading", M_dummy_threading, 1275},
	{"email", M_email, -2852},
	{"email._parseaddr", M_email___parseaddr, 13763},
	{"email.base64mime", M_email__base64mime, 5303},
	{"email.charset", M_email__charset, 13498},
	{"email.encoders", M_email__encoders, 2210},
	{"email.errors", M_email__errors, 3491},
	{"email.feedparser", M_email__feedparser, 11088},
	{"email.generator", M_email__generator, 10339},
	{"email.header", M_email__header, 13622},
	{"email.iterators", M_email__iterators, 2348},
	{"email.message", M_email__message, 28584},
	{"email.mime", M_email__mime, -120},
	{"email.mime.base", M_email__mime__base, 1102},
	{"email.mime.multipart", M_email__mime__multipart, 1655},
	{"email.mime.nonmultipart", M_email__mime__nonmultipart, 872},
	{"email.mime.text", M_email__mime__text, 1294},
	{"email.parser", M_email__parser, 3805},
	{"email.quoprimime", M_email__quoprimime, 8816},
	{"email.utils", M_email__utils, 9120},
	{"encodings", M_encodings, -4362},
	{"encodings.aliases", M_encodings__aliases, 8760},
	{"encodings.cp1252", M_encodings__cp1252, 2866},
	{"fileinput", M_fileinput, 14761},
	{"fnmatch", M_fnmatch, 3514},
	{"formatter", M_formatter, 19016},
	{"fractions", M_fractions, 19647},
	{"ftplib", M_ftplib, 33346},
	{"functools", M_functools, 6029},
	{"genericpath", M_genericpath, 3235},
	{"getopt", M_getopt, 6626},
	{"getpass", M_getpass, 4721},
	{"gettext", M_gettext, 15547},
	{"glib", M_glib, -211},
	{"glib.option", M_glib__option, 12587},
	{"glob", M_glob, 2599},
	{"gobject", M_gobject, -5402},
	{"gobject.constants", M_gobject__constants, 1981},
	{"gobject.propertyhelper", M_gobject__propertyhelper, 9658},
	{"gzip", M_gzip, 14918},
	{"hashlib", M_hashlib, 4388},
	{"heapq", M_heapq, 13398},
	{"httplib", M_httplib, 34972},
	{"inspect", M_inspect, 39854},
	{"io", M_io, 3460},
	{"keyword", M_keyword, 2093},
	{"linecache", M_linecache, 3232},
	{"locale", M_locale, 49861},
	{"logging", M_logging, -57204},
	{"matplotlib", M_matplotlib, -32572},
	{"matplotlib._cm", M_matplotlib___cm, 81412},
	{"matplotlib._mathtext_data", M_matplotlib___mathtext_data, 64634},
	{"matplotlib._pylab_helpers", M_matplotlib___pylab_helpers, 4399},
	{"matplotlib.afm", M_matplotlib__afm, 16778},
	{"matplotlib.artist", M_matplotlib__artist, 40545},
	{"matplotlib.axes", M_matplotlib__axes, 267229},
	{"matplotlib.axis", M_matplotlib__axis, 68181},
	{"matplotlib.backend_bases", M_matplotlib__backend_bases, 97722},
	{"matplotlib.backends", M_matplotlib__backends, -2084},
	{"matplotlib.backends.backend_agg", M_matplotlib__backends__backend_agg, 17976},
	{"matplotlib.backends.backend_emf", M_matplotlib__backends__backend_emf, 28680},
	{"matplotlib.backends.backend_mixed", M_matplotlib__backends__backend_mixed, 4904},
	{"matplotlib.backends.backend_pdf", M_matplotlib__backends__backend_pdf, 70801},
	{"matplotlib.backends.backend_ps", M_matplotlib__backends__backend_ps, 52266},
	{"matplotlib.backends.backend_svg", M_matplotlib__backends__backend_svg, 35102},
	{"matplotlib.bezier", M_matplotlib__bezier, 14396},
	{"matplotlib.blocking_input", M_matplotlib__blocking_input, 14277},
	{"matplotlib.cbook", M_matplotlib__cbook, 71039},
	{"matplotlib.cm", M_matplotlib__cm, 10838},
	{"matplotlib.collections", M_matplotlib__collections, 46251},
	{"matplotlib.colorbar", M_matplotlib__colorbar, 32097},
	{"matplotlib.colors", M_matplotlib__colors, 43468},
	{"matplotlib.container", M_matplotlib__container, 4894},
	{"matplotlib.contour", M_matplotlib__contour, 46620},
	{"matplotlib.dates", M_matplotlib__dates, 43560},
	{"matplotlib.delaunay", M_matplotlib__delaunay, -542},
	{"matplotlib.delaunay.interpolate", M_matplotlib__delaunay__interpolate, 7836},
	{"matplotlib.delaunay.triangulate", M_matplotlib__delaunay__triangulate, 10464},
	{"matplotlib.docstring", M_matplotlib__docstring, 5198},
	{"matplotlib.dviread", M_matplotlib__dviread, 33622},
	{"matplotlib.figure", M_matplotlib__figure, 50750},
	{"matplotlib.finance", M_matplotlib__finance, 19797},
	{"matplotlib.font_manager", M_matplotlib__font_manager, 39880},
	{"matplotlib.fontconfig_pattern", M_matplotlib__fontconfig_pattern, 6530},
	{"matplotlib.gridspec", M_matplotlib__gridspec, 14745},
	{"matplotlib.hatch", M_matplotlib__hatch, 8890},
	{"matplotlib.image", M_matplotlib__image, 44087},
	{"matplotlib.legend", M_matplotlib__legend, 28728},
	{"matplotlib.legend_handler", M_matplotlib__legend_handler, 18524},
	{"matplotlib.lines", M_matplotlib__lines, 40707},
	{"matplotlib.markers", M_matplotlib__markers, 24988},
	{"matplotlib.mathtext", M_matplotlib__mathtext, 108097},
	{"matplotlib.mlab", M_matplotlib__mlab, 105171},
	{"matplotlib.mpl", M_matplotlib__mpl, 1162},
	{"matplotlib.offsetbox", M_matplotlib__offsetbox, 53934},
	{"matplotlib.patches", M_matplotlib__patches, 132885},
	{"matplotlib.path", M_matplotlib__path, 22829},
	{"matplotlib.projections", M_matplotlib__projections, -3375},
	{"matplotlib.projections.geo", M_matplotlib__projections__geo, 26352},
	{"matplotlib.projections.polar", M_matplotlib__projections__polar, 25274},
	{"matplotlib.pylab", M_matplotlib__pylab, 13128},
	{"matplotlib.pyparsing", M_matplotlib__pyparsing, 143150},
	{"matplotlib.pyplot", M_matplotlib__pyplot, 90827},
	{"matplotlib.quiver", M_matplotlib__quiver, 35377},
	{"matplotlib.rcsetup", M_matplotlib__rcsetup, 22264},
	{"matplotlib.scale", M_matplotlib__scale, 19202},
	{"matplotlib.spines", M_matplotlib__spines, 15345},
	{"matplotlib.table", M_matplotlib__table, 16580},
	{"matplotlib.testing", M_matplotlib__testing, -138},
	{"matplotlib.testing.noseclasses", M_matplotlib__testing__noseclasses, 2905},
	{"matplotlib.texmanager", M_matplotlib__texmanager, 19716},
	{"matplotlib.text", M_matplotlib__text, 66717},
	{"matplotlib.textpath", M_matplotlib__textpath, 14517},
	{"matplotlib.ticker", M_matplotlib__ticker, 57196},
	{"matplotlib.tight_bbox", M_matplotlib__tight_bbox, 4129},
	{"matplotlib.tight_layout", M_matplotlib__tight_layout, 6018},
	{"matplotlib.transforms", M_matplotlib__transforms, 90184},
	{"matplotlib.tri", M_matplotlib__tri, -321},
	{"matplotlib.tri.triangulation", M_matplotlib__tri__triangulation, 7007},
	{"matplotlib.tri.tricontour", M_matplotlib__tri__tricontour, 11121},
	{"matplotlib.tri.tripcolor", M_matplotlib__tri__tripcolor, 3300},
	{"matplotlib.tri.triplot", M_matplotlib__tri__triplot, 2292},
	{"matplotlib.type1font", M_matplotlib__type1font, 10992},
	{"matplotlib.units", M_matplotlib__units, 5745},
	{"matplotlib.widgets", M_matplotlib__widgets, 44534},
	{"md5", M_md5, 368},
	{"mimetools", M_mimetools, 8174},
	{"mimetypes", M_mimetypes, 18185},
	{"mpl_toolkits", M_mpl_toolkits, -265},
	{"networkx", M_networkx, -1729},
	{"networkx.algorithms", M_networkx__algorithms, -2080},
	{"networkx.algorithms.assortativity", M_networkx__algorithms__assortativity, -471},
	{"networkx.algorithms.assortativity.connectivity", M_networkx__algorithms__assortativity__connectivity, 3924},
	{"networkx.algorithms.assortativity.correlation", M_networkx__algorithms__assortativity__correlation, 9677},
	{"networkx.algorithms.assortativity.mixing", M_networkx__algorithms__assortativity__mixing, 7775},
	{"networkx.algorithms.assortativity.neighbor_degree", M_networkx__algorithms__assortativity__neighbor_degree, 3949},
	{"networkx.algorithms.assortativity.pairs", M_networkx__algorithms__assortativity__pairs, 4447},
	{"networkx.algorithms.bipartite", M_networkx__algorithms__bipartite, -3409},
	{"networkx.algorithms.bipartite.basic", M_networkx__algorithms__bipartite__basic, 10199},
	{"networkx.algorithms.bipartite.centrality", M_networkx__algorithms__bipartite__centrality, 8673},
	{"networkx.algorithms.bipartite.cluster", M_networkx__algorithms__bipartite__cluster, 5949},
	{"networkx.algorithms.bipartite.projection", M_networkx__algorithms__bipartite__projection, 17901},
	{"networkx.algorithms.bipartite.redundancy", M_networkx__algorithms__bipartite__redundancy, 2490},
	{"networkx.algorithms.bipartite.spectral", M_networkx__algorithms__bipartite__spectral, 2720},
	{"networkx.algorithms.block", M_networkx__algorithms__block, 3647},
	{"networkx.algorithms.boundary", M_networkx__algorithms__boundary, 3080},
	{"networkx.algorithms.centrality", M_networkx__algorithms__centrality, -928},
	{"networkx.algorithms.centrality.betweenness", M_networkx__algorithms__centrality__betweenness, 10291},
	{"networkx.algorithms.centrality.betweenness_subset", M_networkx__algorithms__centrality__betweenness_subset, 8421},
	{"networkx.algorithms.centrality.closeness", M_networkx__algorithms__centrality__closeness, 2343},
	{"networkx.algorithms.centrality.communicability_alg", M_networkx__algorithms__centrality__communicability_alg, 14808},
	{"networkx.algorithms.centrality.current_flow_betweenness", M_networkx__algorithms__centrality__current_flow_betweenness, 13359},
	{"networkx.algorithms.centrality.current_flow_betweenness_subset", M_networkx__algorithms__centrality__current_flow_betweenness_subset, 9492},
	{"networkx.algorithms.centrality.current_flow_closeness", M_networkx__algorithms__centrality__current_flow_closeness, 4547},
	{"networkx.algorithms.centrality.degree_alg", M_networkx__algorithms__centrality__degree_alg, 4517},
	{"networkx.algorithms.centrality.eigenvector", M_networkx__algorithms__centrality__eigenvector, 5442},
	{"networkx.algorithms.centrality.flow_matrix", M_networkx__algorithms__centrality__flow_matrix, 7271},
	{"networkx.algorithms.centrality.load", M_networkx__algorithms__centrality__load, 5232},
	{"networkx.algorithms.chordal", M_networkx__algorithms__chordal, -217},
	{"networkx.algorithms.chordal.chordal_alg", M_networkx__algorithms__chordal__chordal_alg, 11139},
	{"networkx.algorithms.clique", M_networkx__algorithms__clique, 14165},
	{"networkx.algorithms.cluster", M_networkx__algorithms__cluster, 11968},
	{"networkx.algorithms.community", M_networkx__algorithms__community, -217},
	{"networkx.algorithms.community.kclique", M_networkx__algorithms__community__kclique, 2700},
	{"networkx.algorithms.components", M_networkx__algorithms__components, -468},
	{"networkx.algorithms.components.attracting", M_networkx__algorithms__components__attracting, 3775},
	{"networkx.algorithms.components.biconnected", M_networkx__algorithms__components__biconnected, 14398},
	{"networkx.algorithms.components.connected", M_networkx__algorithms__components__connected, 4808},
	{"networkx.algorithms.components.strongly_connected", M_networkx__algorithms__components__strongly_connected, 9016},
	{"networkx.algorithms.components.weakly_connected", M_networkx__algorithms__components__weakly_connected, 3792},
	{"networkx.algorithms.core", M_networkx__algorithms__core, 10569},
	{"networkx.algorithms.cycles", M_networkx__algorithms__cycles, 5927},
	{"networkx.algorithms.dag", M_networkx__algorithms__dag, 6252},
	{"networkx.algorithms.distance_measures", M_networkx__algorithms__distance_measures, 4274},
	{"networkx.algorithms.distance_regular", M_networkx__algorithms__distance_regular, 5533},
	{"networkx.algorithms.euler", M_networkx__algorithms__euler, 3280},
	{"networkx.algorithms.flow", M_networkx__algorithms__flow, -256},
	{"networkx.algorithms.flow.maxflow", M_networkx__algorithms__flow__maxflow, 11684},
	{"networkx.algorithms.flow.mincost", M_networkx__algorithms__flow__mincost, 26170},
	{"networkx.algorithms.graphical", M_networkx__algorithms__graphical, 4147},
	{"networkx.algorithms.hierarchy", M_networkx__algorithms__hierarchy, 2174},
	{"networkx.algorithms.isolate", M_networkx__algorithms__isolate, 1941},
	{"networkx.algorithms.isomorphism", M_networkx__algorithms__isomorphism, -343},
	{"networkx.algorithms.isomorphism.isomorph", M_networkx__algorithms__isomorphism__isomorph, 6858},
	{"networkx.algorithms.isomorphism.isomorphvf2", M_networkx__algorithms__isomorphism__isomorphvf2, 22435},
	{"networkx.algorithms.isomorphism.matchhelpers", M_networkx__algorithms__isomorphism__matchhelpers, 14263},
	{"networkx.algorithms.isomorphism.vf2userfunc", M_networkx__algorithms__isomorphism__vf2userfunc, 7518},
	{"networkx.algorithms.link_analysis", M_networkx__algorithms__link_analysis, -289},
	{"networkx.algorithms.link_analysis.hits_alg", M_networkx__algorithms__link_analysis__hits_alg, 9386},
	{"networkx.algorithms.link_analysis.pagerank_alg", M_networkx__algorithms__link_analysis__pagerank_alg, 12290},
	{"networkx.algorithms.matching", M_networkx__algorithms__matching, 14173},
	{"networkx.algorithms.mis", M_networkx__algorithms__mis, 2403},
	{"networkx.algorithms.mst", M_networkx__algorithms__mst, 7372},
	{"networkx.algorithms.operators", M_networkx__algorithms__operators, -372},
	{"networkx.algorithms.operators.all", M_networkx__algorithms__operators__all, 4705},
	{"networkx.algorithms.operators.binary", M_networkx__algorithms__operators__binary, 9102},
	{"networkx.algorithms.operators.product", M_networkx__algorithms__operators__product, 11852},
	{"networkx.algorithms.operators.unary", M_networkx__algorithms__operators__unary, 1581},
	{"networkx.algorithms.richclub", M_networkx__algorithms__richclub, 3887},
	{"networkx.algorithms.shortest_paths", M_networkx__algorithms__shortest_paths, -463},
	{"networkx.algorithms.shortest_paths.astar", M_networkx__algorithms__shortest_paths__astar, 4207},
	{"networkx.algorithms.shortest_paths.dense", M_networkx__algorithms__shortest_paths__dense, 5393},
	{"networkx.algorithms.shortest_paths.generic", M_networkx__algorithms__shortest_paths__generic, 9974},
	{"networkx.algorithms.shortest_paths.unweighted", M_networkx__algorithms__shortest_paths__unweighted, 8200},
	{"networkx.algorithms.shortest_paths.weighted", M_networkx__algorithms__shortest_paths__weighted, 21666},
	{"networkx.algorithms.simple_paths", M_networkx__algorithms__simple_paths, 4002},
	{"networkx.algorithms.smetric", M_networkx__algorithms__smetric, 1350},
	{"networkx.algorithms.swap", M_networkx__algorithms__swap, 5031},
	{"networkx.algorithms.traversal", M_networkx__algorithms__traversal, -336},
	{"networkx.algorithms.traversal.breadth_first_search", M_networkx__algorithms__traversal__breadth_first_search, 2333},
	{"networkx.algorithms.traversal.depth_first_search", M_networkx__algorithms__traversal__depth_first_search, 4586},
	{"networkx.algorithms.vitality", M_networkx__algorithms__vitality, 2320},
	{"networkx.classes", M_networkx__classes, -480},
	{"networkx.classes.digraph", M_networkx__classes__digraph, 41290},
	{"networkx.classes.function", M_networkx__classes__function, 13611},
	{"networkx.classes.graph", M_networkx__classes__graph, 56632},
	{"networkx.classes.multidigraph", M_networkx__classes__multidigraph, 29154},
	{"networkx.classes.multigraph", M_networkx__classes__multigraph, 30325},
	{"networkx.convert", M_networkx__convert, 25976},
	{"networkx.drawing", M_networkx__drawing, -507},
	{"networkx.drawing.layout", M_networkx__drawing__layout, 13572},
	{"networkx.drawing.nx_agraph", M_networkx__drawing__nx_agraph, 13596},
	{"networkx.drawing.nx_pydot", M_networkx__drawing__nx_pydot, 8931},
	{"networkx.drawing.nx_pylab", M_networkx__drawing__nx_pylab, 24865},
	{"networkx.exception", M_networkx__exception, 2752},
	{"networkx.external", M_networkx__external, -137},
	{"networkx.external.decorator", M_networkx__external__decorator, -367},
	{"networkx.external.decorator._decorator", M_networkx__external__decorator___decorator, 7974},
	{"networkx.external.decorator._decorator3", M_networkx__external__decorator___decorator3, 8074},
	{"networkx.generators", M_networkx__generators, -958},
	{"networkx.generators.atlas", M_networkx__generators__atlas, 167380},
	{"networkx.generators.bipartite", M_networkx__generators__bipartite, 15133},
	{"networkx.generators.classic", M_networkx__generators__classic, 18730},
	{"networkx.generators.degree_seq", M_networkx__generators__degree_seq, 19904},
	{"networkx.generators.directed", M_networkx__generators__directed, 8977},
	{"networkx.generators.ego", M_networkx__generators__ego, 2079},
	{"networkx.generators.geometric", M_networkx__generators__geometric, 11612},
	{"networkx.generators.hybrid", M_networkx__generators__hybrid, 2719},
	{"networkx.generators.intersection", M_networkx__generators__intersection, 4323},
	{"networkx.generators.line", M_networkx__generators__line, 2161},
	{"networkx.generators.random_clustered", M_networkx__generators__random_clustered, 4099},
	{"networkx.generators.random_graphs", M_networkx__generators__random_graphs, 24777},
	{"networkx.generators.small", M_networkx__generators__small, 14533},
	{"networkx.generators.social", M_networkx__generators__social, 9815},
	{"networkx.generators.stochastic", M_networkx__generators__stochastic, 1510},
	{"networkx.generators.threshold", M_networkx__generators__threshold, 25071},
	{"networkx.linalg", M_networkx__linalg, -394},
	{"networkx.linalg.attrmatrix", M_networkx__linalg__attrmatrix, 16371},
	{"networkx.linalg.graphmatrix", M_networkx__linalg__graphmatrix, 5270},
	{"networkx.linalg.laplacianmatrix", M_networkx__linalg__laplacianmatrix, 5542},
	{"networkx.linalg.spectrum", M_networkx__linalg__spectrum, 2616},
	{"networkx.readwrite", M_networkx__readwrite, -759},
	{"networkx.readwrite.adjlist", M_networkx__readwrite__adjlist, 8794},
	{"networkx.readwrite.edgelist", M_networkx__readwrite__edgelist, 13952},
	{"networkx.readwrite.gexf", M_networkx__readwrite__gexf, 26381},
	{"networkx.readwrite.gml", M_networkx__readwrite__gml, 12609},
	{"networkx.readwrite.gpickle", M_networkx__readwrite__gpickle, 3145},
	{"networkx.readwrite.graphml", M_networkx__readwrite__graphml, 18368},
	{"networkx.readwrite.leda", M_networkx__readwrite__leda, 3063},
	{"networkx.readwrite.multiline_adjlist", M_networkx__readwrite__multiline_adjlist, 10662},
	{"networkx.readwrite.nx_shp", M_networkx__readwrite__nx_shp, 6950},
	{"networkx.readwrite.nx_yaml", M_networkx__readwrite__nx_yaml, 3096},
	{"networkx.readwrite.pajek", M_networkx__readwrite__pajek, 6497},
	{"networkx.readwrite.sparsegraph6", M_networkx__readwrite__sparsegraph6, 5545},
	{"networkx.relabel", M_networkx__relabel, 7211},
	{"networkx.release", M_networkx__release, 7407},
	{"networkx.tests", M_networkx__tests, -134},
	{"networkx.tests.test", M_networkx__tests__test, 1543},
	{"networkx.utils", M_networkx__utils, -350},
	{"networkx.utils.decorators", M_networkx__utils__decorators, 6181},
	{"networkx.utils.misc", M_networkx__utils__misc, 4303},
	{"networkx.utils.random_sequence", M_networkx__utils__random_sequence, 7328},
	{"networkx.utils.rcm", M_networkx__utils__rcm, 4979},
	{"networkx.utils.union_find", M_networkx__utils__union_find, 2788},
	{"new", M_new, 852},
	{"ntpath", M_ntpath, 11833},
	{"nturl2path", M_nturl2path, 1801},
	{"numbers", M_numbers, 13880},
	{"numpy", M_numpy, -5219},
	{"numpy.__config__", M_numpy____config__, 1520},
	{"numpy._import_tools", M_numpy___import_tools, 11042},
	{"numpy.add_newdocs", M_numpy__add_newdocs, 252083},
	{"numpy.compat", M_numpy__compat, -615},
	{"numpy.compat._inspect", M_numpy__compat___inspect, 10093},
	{"numpy.compat.py3k", M_numpy__compat__py3k, 2743},
	{"numpy.core", M_numpy__core, -1234},
	{"numpy.core._internal", M_numpy__core___internal, 15716},
	{"numpy.core.arrayprint", M_numpy__core__arrayprint, 16472},
	{"numpy.core.defchararray", M_numpy__core__defchararray, 79425},
	{"numpy.core.fromnumeric", M_numpy__core__fromnumeric, 77707},
	{"numpy.core.function_base", M_numpy__core__function_base, 5820},
	{"numpy.core.getlimits", M_numpy__core__getlimits, 10042},
	{"numpy.core.info", M_numpy__core__info, 4796},
	{"numpy.core.machar", M_numpy__core__machar, 8598},
	{"numpy.core.memmap", M_numpy__core__memmap, 9463},
	{"numpy.core.numeric", M_numpy__core__numeric, 72823},
	{"numpy.core.numerictypes", M_numpy__core__numerictypes, 27434},
	{"numpy.core.records", M_numpy__core__records, 24235},
	{"numpy.core.shape_base", M_numpy__core__shape_base, 7247},
	{"numpy.ctypeslib", M_numpy__ctypeslib, 13107},
	{"numpy.distutils", M_numpy__distutils, -991},
	{"numpy.distutils.__config__", M_numpy__distutils____config__, 1576},
	{"numpy.distutils.__version__", M_numpy__distutils____version__, 276},
	{"numpy.distutils.ccompiler", M_numpy__distutils__ccompiler, 20375},
	{"numpy.distutils.command", M_numpy__distutils__command, -875},
	{"numpy.distutils.command.autodist", M_numpy__distutils__command__autodist, 1193},
	{"numpy.distutils.command.bdist_rpm", M_numpy__distutils__command__bdist_rpm, 1038},
	{"numpy.distutils.command.build", M_numpy__distutils__command__build, 2202},
	{"numpy.distutils.command.build_clib", M_numpy__distutils__command__build_clib, 8263},
	{"numpy.distutils.command.build_ext", M_numpy__distutils__command__build_ext, 13306},
	{"numpy.distutils.command.build_py", M_numpy__distutils__command__build_py, 1522},
	{"numpy.distutils.command.build_scripts", M_numpy__distutils__command__build_scripts, 1885},
	{"numpy.distutils.command.build_src", M_numpy__distutils__command__build_src, 24528},
	{"numpy.distutils.command.config", M_numpy__distutils__command__config, 14394},
	{"numpy.distutils.command.config_compiler", M_numpy__distutils__command__config_compiler, 5753},
	{"numpy.distutils.command.develop", M_numpy__distutils__command__develop, 992},
	{"numpy.distutils.command.egg_info", M_numpy__distutils__command__egg_info, 673},
	{"numpy.distutils.command.install", M_numpy__distutils__command__install, 2625},
	{"numpy.distutils.command.install_clib", M_numpy__distutils__command__install_clib, 2104},
	{"numpy.distutils.command.install_data", M_numpy__distutils__command__install_data, 1188},
	{"numpy.distutils.command.install_headers", M_numpy__distutils__command__install_headers, 1235},
	{"numpy.distutils.command.scons", M_numpy__distutils__command__scons, 21739},
	{"numpy.distutils.command.sdist", M_numpy__distutils__command__sdist, 1185},
	{"numpy.distutils.compat", M_numpy__distutils__compat, 462},
	{"numpy.distutils.conv_template", M_numpy__distutils__conv_template, 9560},
	{"numpy.distutils.core", M_numpy__distutils__core, 6473},
	{"numpy.distutils.cpuinfo", M_numpy__distutils__cpuinfo, 43574},
	{"numpy.distutils.environment", M_numpy__distutils__environment, 3331},
	{"numpy.distutils.exec_command", M_numpy__distutils__exec_command, 17256},
	{"numpy.distutils.extension", M_numpy__distutils__extension, 2452},
	{"numpy.distutils.fcompiler", M_numpy__distutils__fcompiler, -33618},
	{"numpy.distutils.from_template", M_numpy__distutils__from_template, 8357},
	{"numpy.distutils.info", M_numpy__distutils__info, 256},
	{"numpy.distutils.interactive", M_numpy__distutils__interactive, 5747},
	{"numpy.distutils.lib2def", M_numpy__distutils__lib2def, 3836},
	{"numpy.distutils.log", M_numpy__distutils__log, 2931},
	{"numpy.distutils.mingw32ccompiler", M_numpy__distutils__mingw32ccompiler, 14100},
	{"numpy.distutils.misc_util", M_numpy__distutils__misc_util, 80652},
	{"numpy.distutils.npy_pkg_config", M_numpy__distutils__npy_pkg_config, 15571},
	{"numpy.distutils.numpy_distribution", M_numpy__distutils__numpy_distribution, 965},
	{"numpy.distutils.system_info", M_numpy__distutils__system_info, 71559},
	{"numpy.distutils.unixccompiler", M_numpy__distutils__unixccompiler, 3274},
	{"numpy.dual", M_numpy__dual, 2149},
	{"numpy.f2py", M_numpy__f2py, -1512},
	{"numpy.f2py.__version__", M_numpy__f2py____version__, 363},
	{"numpy.f2py.auxfuncs", M_numpy__f2py__auxfuncs, 30622},
	{"numpy.f2py.capi_maps", M_numpy__f2py__capi_maps, 21780},
	{"numpy.f2py.cb_rules", M_numpy__f2py__cb_rules, 16424},
	{"numpy.f2py.cfuncs", M_numpy__f2py__cfuncs, 37120},
	{"numpy.f2py.common_rules", M_numpy__f2py__common_rules, 5656},
	{"numpy.f2py.crackfortran", M_numpy__f2py__crackfortran, 80450},
	{"numpy.f2py.diagnose", M_numpy__f2py__diagnose, 3807},
	{"numpy.f2py.f2py2e", M_numpy__f2py__f2py2e, 21358},
	{"numpy.f2py.f2py_testing", M_numpy__f2py__f2py_testing, 1641},
	{"numpy.f2py.f90mod_rules", M_numpy__f2py__f90mod_rules, 8763},
	{"numpy.f2py.func2subr", M_numpy__f2py__func2subr, 7813},
	{"numpy.f2py.info", M_numpy__f2py__info, 230},
	{"numpy.f2py.rules", M_numpy__f2py__rules, 37438},
	{"numpy.f2py.use_rules", M_numpy__f2py__use_rules, 3655},
	{"numpy.fft", M_numpy__fft, -347},
	{"numpy.fft.fftpack", M_numpy__fft__fftpack, 41399},
	{"numpy.fft.helper", M_numpy__fft__helper, 4780},
	{"numpy.fft.info", M_numpy__fft__info, 6780},
	{"numpy.lib", M_numpy__lib, -1000},
	{"numpy.lib._datasource", M_numpy__lib___datasource, 20877},
	{"numpy.lib._iotools", M_numpy__lib___iotools, 28228},
	{"numpy.lib.arraysetops", M_numpy__lib__arraysetops, 11463},
	{"numpy.lib.arrayterator", M_numpy__lib__arrayterator, 7707},
	{"numpy.lib.financial", M_numpy__lib__financial, 21736},
	{"numpy.lib.format", M_numpy__lib__format, 17714},
	{"numpy.lib.function_base", M_numpy__lib__function_base, 106548},
	{"numpy.lib.index_tricks", M_numpy__lib__index_tricks, 26148},
	{"numpy.lib.info", M_numpy__lib__info, 6415},
	{"numpy.lib.npyio", M_numpy__lib__npyio, 51004},
	{"numpy.lib.polynomial", M_numpy__lib__polynomial, 38247},
	{"numpy.lib.scimath", M_numpy__lib__scimath, 15833},
	{"numpy.lib.shape_base", M_numpy__lib__shape_base, 25109},
	{"numpy.lib.stride_tricks", M_numpy__lib__stride_tricks, 3731},
	{"numpy.lib.twodim_base", M_numpy__lib__twodim_base, 25793},
	{"numpy.lib.type_check", M_numpy__lib__type_check, 18590},
	{"numpy.lib.ufunclike", M_numpy__lib__ufunclike, 5457},
	{"numpy.lib.utils", M_numpy__lib__utils, 32694},
	{"numpy.linalg", M_numpy__linalg, -2365},
	{"numpy.linalg.info", M_numpy__linalg__info, 1291},
	{"numpy.linalg.linalg", M_numpy__linalg__linalg, 59642},
	{"numpy.ma", M_numpy__ma, -1718},
	{"numpy.ma.core", M_numpy__ma__core, 208328},
	{"numpy.ma.extras", M_numpy__ma__extras, 53077},
	{"numpy.ma.mrecords", M_numpy__ma__mrecords, 23335},
	{"numpy.matrixlib", M_numpy__matrixlib, -393},
	{"numpy.matrixlib.defmatrix", M_numpy__matrixlib__defmatrix, 31570},
	{"numpy.numarray", M_numpy__numarray, -632},
	{"numpy.numarray.compat", M_numpy__numarray__compat, 274},
	{"numpy.numarray.functions", M_numpy__numarray__functions, 18434},
	{"numpy.numarray.numerictypes", M_numpy__numarray__numerictypes, 13598},
	{"numpy.numarray.session", M_numpy__numarray__session, 13199},
	{"numpy.numarray.ufuncs", M_numpy__numarray__ufuncs, 1994},
	{"numpy.numarray.util", M_numpy__numarray__util, 2156},
	{"numpy.oldnumeric", M_numpy__oldnumeric, -1010},
	{"numpy.oldnumeric.array_printer", M_numpy__oldnumeric__array_printer, 655},
	{"numpy.oldnumeric.compat", M_numpy__oldnumeric__compat, 4957},
	{"numpy.oldnumeric.functions", M_numpy__oldnumeric__functions, 7410},
	{"numpy.oldnumeric.misc", M_numpy__oldnumeric__misc, 1559},
	{"numpy.oldnumeric.precision", M_numpy__oldnumeric__precision, 3921},
	{"numpy.oldnumeric.typeconv", M_numpy__oldnumeric__typeconv, 1609},
	{"numpy.oldnumeric.ufuncs", M_numpy__oldnumeric__ufuncs, 1820},
	{"numpy.polynomial", M_numpy__polynomial, -17729},
	{"numpy.polynomial.chebyshev", M_numpy__polynomial__chebyshev, 43641},
	{"numpy.polynomial.hermite", M_numpy__polynomial__hermite, 36698},
	{"numpy.polynomial.hermite_e", M_numpy__polynomial__hermite_e, 36576},
	{"numpy.polynomial.laguerre", M_numpy__polynomial__laguerre, 36288},
	{"numpy.polynomial.legendre", M_numpy__polynomial__legendre, 37337},
	{"numpy.polynomial.polynomial", M_numpy__polynomial__polynomial, 30639},
	{"numpy.polynomial.polytemplate", M_numpy__polynomial__polytemplate, 27616},
	{"numpy.polynomial.polyutils", M_numpy__polynomial__polyutils, 12659},
	{"numpy.random", M_numpy__random, -5012},
	{"numpy.random.info", M_numpy__random__info, 5325},
	{"numpy.testing", M_numpy__testing, -667},
	{"numpy.testing.decorators", M_numpy__testing__decorators, 9680},
	{"numpy.testing.noseclasses", M_numpy__testing__noseclasses, 11885},
	{"numpy.testing.nosetester", M_numpy__testing__nosetester, 13303},
	{"numpy.testing.numpytest", M_numpy__testing__numpytest, 1940},
	{"numpy.testing.utils", M_numpy__testing__utils, 48233},
	{"numpy.version", M_numpy__version, 325},
	{"opcode", M_opcode, 6134},
	{"optparse", M_optparse, 53761},
	{"os", M_os, 25443},
	{"os2emxpath", M_os2emxpath, 4466},
	{"pdb", M_pdb, 43377},
	{"pickle", M_pickle, 38223},
	{"pkgutil", M_pkgutil, 18859},
	{"platform", M_platform, 37353},
	{"plistlib", M_plistlib, 19121},
	{"posixpath", M_posixpath, 11457},
	{"pprint", M_pprint, 10195},
	{"problem_report", M_problem_report, 17626},
	{"py_compile", M_py_compile, 6410},
	{"pydoc", M_pydoc, 90507},
	{"pydoc_data", M_pydoc_data, -120},
	{"pydoc_data.topics", M_pydoc_data__topics, 392396},
	{"pydot", M_pydot, 48733},
	{"pylab", M_pylab, 228},
	{"pyparsing", M_pyparsing, 148887},
	{"pytz", M_pytz, -33073},
	{"pytz.exceptions", M_pytz__exceptions, 2041},
	{"pytz.tzfile", M_pytz__tzfile, 3854},
	{"pytz.tzinfo", M_pytz__tzinfo, 16551},
	{"quopri", M_quopri, 6542},
	{"random", M_random, 25541},
	{"re", M_re, 13044},
	{"repr", M_repr, 5343},
	{"rfc822", M_rfc822, 31661},
	{"scipy", M_scipy, -4876},
	{"scipy.__config__", M_scipy____config__, 1890},
	{"scipy.integrate", M_scipy__integrate, -2228},
	{"scipy.integrate._ode", M_scipy__integrate___ode, 27348},
	{"scipy.integrate.odepack", M_scipy__integrate__odepack, 6629},
	{"scipy.integrate.quadpack", M_scipy__integrate__quadpack, 21087},
	{"scipy.integrate.quadrature", M_scipy__integrate__quadrature, 24833},
	{"scipy.lib", M_scipy__lib, -458},
	{"scipy.lib.lapack", M_scipy__lib__lapack, -2458},
	{"scipy.lib.lapack.info", M_scipy__lib__lapack__info, 4544},
	{"scipy.linalg", M_scipy__linalg, -4841},
	{"scipy.linalg.basic", M_scipy__linalg__basic, 16362},
	{"scipy.linalg.blas", M_scipy__linalg__blas, 3056},
	{"scipy.linalg.decomp", M_scipy__linalg__decomp, 24248},
	{"scipy.linalg.decomp_cholesky", M_scipy__linalg__decomp_cholesky, 7951},
	{"scipy.linalg.decomp_lu", M_scipy__linalg__decomp_lu, 4981},
	{"scipy.linalg.decomp_qr", M_scipy__linalg__decomp_qr, 9928},
	{"scipy.linalg.decomp_schur", M_scipy__linalg__decomp_schur, 8839},
	{"scipy.linalg.decomp_svd", M_scipy__linalg__decomp_svd, 5619},
	{"scipy.linalg.flinalg", M_scipy__linalg__flinalg, 1627},
	{"scipy.linalg.lapack", M_scipy__linalg__lapack, 3043},
	{"scipy.linalg.linalg_version", M_scipy__linalg__linalg_version, 288},
	{"scipy.linalg.matfuncs", M_scipy__linalg__matfuncs, 15601},
	{"scipy.linalg.misc", M_scipy__linalg__misc, 1353},
	{"scipy.linalg.special_matrices", M_scipy__linalg__special_matrices, 19908},
	{"scipy.misc", M_scipy__misc, -2309},
	{"scipy.misc.common", M_scipy__misc__common, 12095},
	{"scipy.misc.doccer", M_scipy__misc__doccer, 4439},
	{"scipy.misc.pilutil", M_scipy__misc__pilutil, 13300},
	{"scipy.optimize", M_scipy__optimize, -3720},
	{"scipy.optimize.anneal", M_scipy__optimize__anneal, 13799},
	{"scipy.optimize.cobyla", M_scipy__optimize__cobyla, 5670},
	{"scipy.optimize.lbfgsb", M_scipy__optimize__lbfgsb, 7902},
	{"scipy.optimize.linesearch", M_scipy__optimize__linesearch, 15160},
	{"scipy.optimize.minpack", M_scipy__optimize__minpack, 18911},
	{"scipy.optimize.nnls", M_scipy__optimize__nnls, 1741},
	{"scipy.optimize.nonlin", M_scipy__optimize__nonlin, 51918},
	{"scipy.optimize.optimize", M_scipy__optimize__optimize, 51490},
	{"scipy.optimize.slsqp", M_scipy__optimize__slsqp, 10241},
	{"scipy.optimize.tnc", M_scipy__optimize__tnc, 10148},
	{"scipy.optimize.zeros", M_scipy__optimize__zeros, 16330},
	{"scipy.sparse", M_scipy__sparse, -5062},
	{"scipy.sparse.base", M_scipy__sparse__base, 20626},
	{"scipy.sparse.bsr", M_scipy__sparse__bsr, 17678},
	{"scipy.sparse.compressed", M_scipy__sparse__compressed, 20372},
	{"scipy.sparse.construct", M_scipy__sparse__construct, 13083},
	{"scipy.sparse.coo", M_scipy__sparse__coo, 12785},
	{"scipy.sparse.csc", M_scipy__sparse__csc, 6052},
	{"scipy.sparse.csgraph", M_scipy__sparse__csgraph, 2705},
	{"scipy.sparse.csr", M_scipy__sparse__csr, 12205},
	{"scipy.sparse.data", M_scipy__sparse__data, 3328},
	{"scipy.sparse.dia", M_scipy__sparse__dia, 7555},
	{"scipy.sparse.dok", M_scipy__sparse__dok, 16078},
	{"scipy.sparse.extract", M_scipy__sparse__extract, 5067},
	{"scipy.sparse.lil", M_scipy__sparse__lil, 14464},
	{"scipy.sparse.linalg", M_scipy__sparse__linalg, -681},
	{"scipy.sparse.linalg.dsolve", M_scipy__sparse__linalg__dsolve, -1983},
	{"scipy.sparse.linalg.dsolve.info", M_scipy__sparse__linalg__dsolve__info, 1611},
	{"scipy.sparse.linalg.dsolve.linsolve", M_scipy__sparse__linalg__dsolve__linsolve, 9338},
	{"scipy.sparse.linalg.dsolve.umfpack", M_scipy__sparse__linalg__dsolve__umfpack, -574},
	{"scipy.sparse.linalg.dsolve.umfpack._umfpack", M_scipy__sparse__linalg__dsolve__umfpack___umfpack, 30946},
	{"scipy.sparse.linalg.dsolve.umfpack.info", M_scipy__sparse__linalg__dsolve__umfpack__info, 4708},
	{"scipy.sparse.linalg.dsolve.umfpack.umfpack", M_scipy__sparse__linalg__dsolve__umfpack__umfpack, 20922},
	{"scipy.sparse.linalg.eigen", M_scipy__sparse__linalg__eigen, -640},
	{"scipy.sparse.linalg.eigen.arpack", M_scipy__sparse__linalg__eigen__arpack, -242},
	{"scipy.sparse.linalg.eigen.arpack.arpack", M_scipy__sparse__linalg__eigen__arpack__arpack, 50816},
	{"scipy.sparse.linalg.eigen.arpack.info", M_scipy__sparse__linalg__eigen__arpack__info, 767},
	{"scipy.sparse.linalg.eigen.info", M_scipy__sparse__linalg__eigen__info, 445},
	{"scipy.sparse.linalg.eigen.lobpcg", M_scipy__sparse__linalg__eigen__lobpcg, -434},
	{"scipy.sparse.linalg.eigen.lobpcg.info", M_scipy__sparse__linalg__eigen__lobpcg__info, 4000},
	{"scipy.sparse.linalg.eigen.lobpcg.lobpcg", M_scipy__sparse__linalg__eigen__lobpcg__lobpcg, 13724},
	{"scipy.sparse.linalg.info", M_scipy__sparse__linalg__info, 2509},
	{"scipy.sparse.linalg.interface", M_scipy__sparse__linalg__interface, 9366},
	{"scipy.sparse.linalg.isolve", M_scipy__sparse__linalg__isolve, -718},
	{"scipy.sparse.linalg.isolve.iterative", M_scipy__sparse__linalg__isolve__iterative, 18725},
	{"scipy.sparse.linalg.isolve.lgmres", M_scipy__sparse__linalg__isolve__lgmres, 7132},
	{"scipy.sparse.linalg.isolve.lsqr", M_scipy__sparse__linalg__isolve__lsqr, 15384},
	{"scipy.sparse.linalg.isolve.minres", M_scipy__sparse__linalg__isolve__minres, 6824},
	{"scipy.sparse.linalg.isolve.utils", M_scipy__sparse__linalg__isolve__utils, 4183},
	{"scipy.sparse.sparsetools", M_scipy__sparse__sparsetools, -379},
	{"scipy.sparse.sparsetools.bsr", M_scipy__sparse__sparsetools__bsr, 29034},
	{"scipy.sparse.sparsetools.coo", M_scipy__sparse__sparsetools__coo, 9911},
	{"scipy.sparse.sparsetools.csc", M_scipy__sparse__sparsetools__csc, 21715},
	{"scipy.sparse.sparsetools.csgraph", M_scipy__sparse__sparsetools__csgraph, 3029},
	{"scipy.sparse.sparsetools.csr", M_scipy__sparse__sparsetools__csr, 35248},
	{"scipy.sparse.sparsetools.dia", M_scipy__sparse__sparsetools__dia, 4811},
	{"scipy.sparse.spfuncs", M_scipy__sparse__spfuncs, 2534},
	{"scipy.sparse.sputils", M_scipy__sparse__sputils, 4334},
	{"scipy.spatial", M_scipy__spatial, -1159},
	{"scipy.spatial.distance", M_scipy__spatial__distance, 65902},
	{"scipy.spatial.kdtree", M_scipy__spatial__kdtree, 31398},
	{"scipy.special", M_scipy__special, -19204},
	{"scipy.special.add_newdocs", M_scipy__special__add_newdocs, 1723},
	{"scipy.special.basic", M_scipy__special__basic, 36192},
	{"scipy.special.orthogonal", M_scipy__special__orthogonal, 31964},
	{"scipy.special.spfun_stats", M_scipy__special__spfun_stats, 2249},
	{"scipy.stats", M_scipy__stats, -8890},
	{"scipy.stats._support", M_scipy__stats___support, 8463},
	{"scipy.stats.contingency", M_scipy__stats__contingency, 7860},
	{"scipy.stats.distributions", M_scipy__stats__distributions, 286714},
	{"scipy.stats.kde", M_scipy__stats__kde, 10063},
	{"scipy.stats.morestats", M_scipy__stats__morestats, 48098},
	{"scipy.stats.mstats", M_scipy__stats__mstats, 1621},
	{"scipy.stats.mstats_basic", M_scipy__stats__mstats_basic, 71470},
	{"scipy.stats.mstats_extras", M_scipy__stats__mstats_extras, 14022},
	{"scipy.stats.rv", M_scipy__stats__rv, 2102},
	{"scipy.stats.stats", M_scipy__stats__stats, 120553},
	{"scipy.version", M_scipy__version, 326},
	{"sets", M_sets, 16775},
	{"shlex", M_shlex, 7508},
	{"shutil", M_shutil, 18279},
	{"site", M_site, 19734},
	{"sitecustomize", M_sitecustomize, 224},
	{"socket", M_socket, 16023},
	{"sre_compile", M_sre_compile, 11021},
	{"sre_constants", M_sre_constants, 6070},
	{"sre_parse", M_sre_parse, 19020},
	{"ssl", M_ssl, 14492},
	{"stat", M_stat, 2723},
	{"string", M_string, 19898},
	{"struct", M_struct, 229},
	{"subprocess", M_subprocess, 40004},
	{"symbol", M_symbol, 3014},
	{"symtable", M_symtable, 11759},
	{"sysconfig", M_sysconfig, 19385},
	{"tarfile", M_tarfile, 74740},
	{"tempfile", M_tempfile, 19747},
	{"textwrap", M_textwrap, 11863},
	{"threading", M_threading, 28235},
	{"token", M_token, 3798},
	{"tokenize", M_tokenize, 13857},
	{"traceback", M_traceback, 11575},
	{"tty", M_tty, 1303},
	{"types", M_types, 2486},
	{"unittest", M_unittest, -2955},
	{"unittest.case", M_unittest__case, 39475},
	{"unittest.loader", M_unittest__loader, 11278},
	{"unittest.main", M_unittest__main, 7837},
	{"unittest.result", M_unittest__result, 7868},
	{"unittest.runner", M_unittest__runner, 7590},
	{"unittest.signals", M_unittest__signals, 2280},
	{"unittest.suite", M_unittest__suite, 10460},
	{"unittest.util", M_unittest__util, 4494},
	{"urllib", M_urllib, 49703},
	{"urllib2", M_urllib2, 46418},
	{"urlparse", M_urlparse, 13796},
	{"uu", M_uu, 4294},
	{"uuid", M_uuid, 21095},
	{"warnings", M_warnings, 13096},
	{"weakref", M_weakref, 13938},
	{"webbrowser", M_webbrowser, 19146},
	{"xml", M_xml, -1068},
	{"xml.dom", M_xml__dom, -6427},
	{"xml.dom.NodeFilter", M_xml__dom__NodeFilter, 1112},
	{"xml.dom.domreg", M_xml__dom__domreg, 3293},
	{"xml.dom.expatbuilder", M_xml__dom__expatbuilder, 33002},
	{"xml.dom.minicompat", M_xml__dom__minicompat, 3521},
	{"xml.dom.minidom", M_xml__dom__minidom, 65319},
	{"xml.dom.pulldom", M_xml__dom__pulldom, 12986},
	{"xml.dom.xmlbuilder", M_xml__dom__xmlbuilder, 16396},
	{"xml.etree", M_xml__etree, -119},
	{"xml.etree.ElementPath", M_xml__etree__ElementPath, 7558},
	{"xml.etree.ElementTree", M_xml__etree__ElementTree, 34673},
	{"xml.etree.cElementTree", M_xml__etree__cElementTree, 166},
	{"xml.parsers", M_xml__parsers, -304},
	{"xml.parsers.expat", M_xml__parsers__expat, 277},
	{"xml.sax", M_xml__sax, -3679},
	{"xml.sax._exceptions", M_xml__sax___exceptions, 6127},
	{"xml.sax.expatreader", M_xml__sax__expatreader, 14275},
	{"xml.sax.handler", M_xml__sax__handler, 12970},
	{"xml.sax.saxutils", M_xml__sax__saxutils, 13256},
	{"xml.sax.xmlreader", M_xml__sax__xmlreader, 19078},
	{"yaml", M_yaml, -11348},
	{"yaml.composer", M_yaml__composer, 4496},
	{"yaml.constructor", M_yaml__constructor, 21801},
	{"yaml.cyaml", M_yaml__cyaml, 3780},
	{"yaml.dumper", M_yaml__dumper, 2545},
	{"yaml.emitter", M_yaml__emitter, 31814},
	{"yaml.error", M_yaml__error, 2937},
	{"yaml.events", M_yaml__events, 4886},
	{"yaml.loader", M_yaml__loader, 1868},
	{"yaml.nodes", M_yaml__nodes, 2158},
	{"yaml.parser", M_yaml__parser, 14635},
	{"yaml.reader", M_yaml__reader, 5554},
	{"yaml.representer", M_yaml__representer, 14578},
	{"yaml.resolver", M_yaml__resolver, 6604},
	{"yaml.scanner", M_yaml__scanner, 32896},
	{"yaml.serializer", M_yaml__serializer, 4303},
	{"yaml.tokens", M_yaml__tokens, 6421},
	{"zipfile", M_zipfile, 38793},

    {0, 0, 0} /* sentinel */
};

int
main(int argc, char **argv)
{
        extern int Py_FrozenMain(int, char **);

        PyImport_FrozenModules = _PyImport_FrozenModules;
        return Py_FrozenMain(argc, argv);
}

